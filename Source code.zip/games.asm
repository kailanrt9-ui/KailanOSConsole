bits 16
org 0x8000

game_start:
    mov ax, 0x0003
    int 0x10

    mov byte [px], 10
    mov byte [py], 10
    mov word [score], 0

    call new_star

draw:
    mov ax, 0x0003
    int 0x10

    mov si, title
    call print

    mov si, score_msg
    call print
    mov ax, [score]
    call print_num

    mov dh, [stary]
    mov dl, [starx]
    call cursor
    mov al, '*'
    call chr

    mov dh, [py]
    mov dl, [px]
    call cursor
    mov al, '@'
    call chr

    mov dh, 23
    mov dl, 0
    call cursor
    mov si, info
    call print

key:
    xor ah, ah
    int 0x16

    cmp ah, 0x48
    je up
    cmp ah, 0x50
    je down
    cmp ah, 0x4B
    je left
    cmp ah, 0x4D
    je right
    cmp al, 27
    je quit

    jmp key

up:
    cmp byte [py], 3
    jbe draw
    dec byte [py]
    jmp check

down:
    cmp byte [py], 22
    jae draw
    inc byte [py]
    jmp check

left:
    cmp byte [px], 0
    jbe draw
    dec byte [px]
    jmp check

right:
    cmp byte [px], 79
    jae draw
    inc byte [px]
    jmp check

check:
    mov al, [px]
    cmp al, [starx]
    jne draw

    mov al, [py]
    cmp al, [stary]
    jne draw

    inc word [score]
    call new_star
    jmp draw

new_star:
    ; fake-random using BIOS timer
    mov ah, 0x00
    int 0x1A          ; CX:DX = timer ticks

    mov ax, dx
    xor dx, dx
    mov bx, 76
    div bx
    add dl, 2
    mov [starx], dl

    mov ah, 0x00
    int 0x1A

    mov ax, dx
    xor dx, dx
    mov bx, 18
    div bx
    add dl, 4
    mov [stary], dl

    ret

print_num:
    ; prints AX as decimal
    mov bx, 10
    xor cx, cx

.convert:
    xor dx, dx
    div bx
    push dx
    inc cx
    cmp ax, 0
    jne .convert

.print_digits:
    pop dx
    add dl, '0'
    mov al, dl
    call chr
    loop .print_digits
    ret

quit:
    mov ax, 0x0003
    int 0x10
    mov si, bye
    call print

hang:
    jmp hang

cursor:
    mov ah, 0x02
    mov bh, 0
    int 0x10
    ret

chr:
    mov ah, 0x0E
    int 0x10
    ret

print:
    mov ah, 0x0E
.next:
    lodsb
    cmp al, 0
    je .done
    int 0x10
    jmp .next
.done:
    ret

px db 10
py db 10
starx db 30
stary db 12
score dw 0

title db 'STAR COLLECTOR',13,10,13,10,0
score_msg db 'Stars: ',0
info db 'Arrow keys move @. Collect * forever. ESC quits.',0
bye db 'Game stopped.',0
