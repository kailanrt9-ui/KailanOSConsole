bits 16
org 0x7C00

start:
    mov [boot_drive], dl

    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00
    sti

    mov ax, 0x0003
    int 0x10

dashboard:
    mov si, title
    call print

wait_key:
    xor ah, ah
    int 0x16

    cmp al, 13          ; ENTER
    je launch_game

    jmp wait_key

launch_game:
    mov ax, 0x0003
    int 0x10

    mov si, loading
    call print

    mov ah, 0x02        ; read sectors
    mov al, 4           ; load 4 sectors of games.bin
    mov ch, 0
    mov cl, 2           ; sector 2 = right after boot sector
    mov dh, 0
    mov dl, [boot_drive]
    mov bx, 0x8000
    int 0x13

    jc disk_error

    jmp 0x0000:0x8000

disk_error:
    mov si, err
    call print
    jmp $

print:
    mov ah, 0x0E
.next:
    lodsb
    cmp al, 0
    je .done
    int 0x10
    jmp .next
.done:
    ret

boot_drive db 0

title db 13,10
      db '==============================',13,10
      db '      KAILAN OS DASHBOARD',13,10
      db '==============================',13,10,13,10
      db '   > [*] Star Collector',13,10,13,10
      db 'Press ENTER to launch',13,10,0

loading db 'Launching Star Collector...',13,10,0
err db 'Disk error loading games.bin!',0

times 510-($-$$) db 0
dw 0xAA55
